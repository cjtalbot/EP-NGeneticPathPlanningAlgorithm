var CanvasRenderingContext2D;
var FlashCanvas;
var G_vmlCanvasManager;
var swf;

CanvasRenderingContext2D.loadImage;
FlashCanvas.initElement;
FlashCanvas.saveImage;
FlashCanvas.setOptions;
FlashCanvas.trigger;
FlashCanvas.unlock;
G_vmlCanvasManager.init;
G_vmlCanvasManager.init_;
G_vmlCanvasManager.initElement;
swf.CallFunction;
swf.resize;
swf.saveImage;
